# FITBOT - Azhar Fitness Center Automation System

![FITBOT Logo](https://img.shields.io/badge/FITBOT-Azhar%20Fitness-orange?style=for-the-badge)
![Status](https://img.shields.io/badge/Status-Active-green?style=for-the-badge)

## 🔥 Overview

**FITBOT** is a comprehensive gym automation system built for Azhar Fitness Center. It combines AI-powered WhatsApp messaging, member management, and automated Instagram content generation to create a high-energy, motivational fitness experience.

### ✨ Key Features

- 🤖 **AI-Powered WhatsApp Bot** - Automated member engagement with anti-repetition logic
- 💪 **Retention Mode** - Automatically detects and re-engages inactive members (>3 days)
- 📸 **Instagram Content Generator** - Daily HD 9:16 stories with consistent branding
- 👥 **Member Management** - Full CRUD with Excel import/export
- 🎯 **Interactive Buttons** - WhatsApp messages include actionable buttons
- 🧠 **10+ Greeting Variations** - Never repeats the same message twice
- 📊 **Admin Dashboard** - Real-time member stats and analytics
- ⏰ **Automated Scheduling** - Daily tasks run automatically

## 🎨 Design & Branding

- **Colors**: Blue, Orange, Chrome
- **Personality**: High-Energy, No-Nonsense, Motivational, Dynamic
- **Theme**: Professional fitness with dramatic lighting

## 🚀 Technology Stack

### Backend
- **Framework**: FastAPI (Python 3.11)
- **Database**: MongoDB
- **AI Integration**: OpenAI GPT-3.5-turbo for conversations
- **Image Generation**: OpenAI GPT Image 1
- **WhatsApp**: WhatsApp Business API
- **Scheduler**: APScheduler for automated tasks
- **Authentication**: JWT with bcrypt

### Frontend
- **Framework**: React 19
- **UI Components**: Radix UI with Tailwind CSS
- **Routing**: React Router DOM
- **Data Handling**: Axios
- **Excel Support**: XLSX.js & file-saver
- **Notifications**: Sonner (toast notifications)

## 📦 Installation & Setup

### Prerequisites
- Python 3.11+
- Node.js 18+
- MongoDB (running locally)
- Yarn package manager

### Backend Setup

```bash
cd /app/backend

# Install dependencies
pip install -r requirements.txt

# Configure environment variables in .env
# See .env file for all configuration options

# Start the backend (managed by supervisor)
sudo supervisorctl restart backend
```

### Frontend Setup

```bash
cd /app/frontend

# Install dependencies
yarn install

# Start the frontend (managed by supervisor)
sudo supervisorctl restart frontend
```

## 🔐 Admin Credentials

**Email**: Admin@azhartrainer.com  
**Password**: Admin

## 📱 FITBOT Features in Detail

### 1. Anti-Repetition Logic

FITBOT uses 10+ unique greeting variations to ensure members never receive the same message twice:

- 🔥 "Time to crush it at Azhar Fitness Center! Your gains are waiting!"
- 💪 "The iron doesn't lift itself. Let's GO!"
- ⚡ "Your body is calling - answer at AFC Gym NOW!"
- ...and 9 more variations!

### 2. Retention Mode (Inactive Member Detection)

Automatically triggers when a member hasn't checked in for >3 days:

- Sends personalized, high-energy messages
- Uses psychological triggers like:
  - "The only bad workout is the one that didn't happen."
  - "Your goals don't care if you're tired."
- Includes interactive WhatsApp buttons

### 3. Instagram Automation

Generates daily HD 9:16 stories rotating through 4 themes:

1. **Heavy Lifting** - Intense workout scenes
2. **Healthy Meal Prep** - Nutrition and supplements
3. **Success Quotes** - Motivational typography
4. **Call to Action** - "SEE YOU AT AFC GYM" promotions

### 4. WhatsApp Interactive Buttons

Every automated message includes action buttons:
- "Let's Go!" 
- "Not Today"
- "Contact Admin"

## 📊 Admin Dashboard

### Dashboard Features

1. **Member Statistics**
   - Total members
   - Active members
   - Inactive members (>3 days)
   - Check-ins today

2. **Member Management**
   - Add/Edit/Delete members
   - Record check-ins
   - Excel import/export
   - Search and filter

3. **WhatsApp Panel**
   - Send manual messages
   - Test automation
   - View message templates
   - Configure buttons

4. **Instagram Content**
   - Generate new content
   - Preview generated stories
   - View content history
   - Download images

5. **Settings**
   - View system configuration
   - API key management
   - Automation schedule
   - System information

## 🔄 Automated Tasks

### Daily Schedule

| Time | Task | Description |
|------|------|-------------|
| 9:00 AM | Inactive Member Check | Scans for members inactive >3 days and sends retention messages |
| 10:00 AM | Instagram Generation | Creates daily HD story with rotating theme |

### Manual Triggers

Both automated tasks can be triggered manually from the admin dashboard:
- **WhatsApp Panel** → "Test Inactive Member Check"
- **Instagram Panel** → "Generate New Content"

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/login` - Admin login

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics

### Members
- `GET /api/members` - List all members
- `POST /api/members` - Create new member
- `PUT /api/members/{id}` - Update member
- `DELETE /api/members/{id}` - Delete member
- `POST /api/members/{id}/checkin` - Record check-in

### WhatsApp
- `POST /api/whatsapp/send` - Send message
- `POST /api/whatsapp/test-inactive` - Test inactive check

### Instagram
- `GET /api/instagram/posts` - List generated posts
- `POST /api/instagram/generate` - Generate new content

## 🎯 Usage Examples

### Adding a Member via UI

1. Login to admin dashboard
2. Navigate to "Members"
3. Click "Add Member"
4. Fill in details (name, phone, email)
5. Click "Add Member"

### Bulk Import Members

1. Navigate to "Members"
2. Click "Import Excel"
3. Select Excel file with columns: Name, Phone, Email
4. Members are automatically imported

### Sending WhatsApp Message

1. Navigate to "WhatsApp"
2. Enter phone number (with country code)
3. Type your message
4. Optionally customize button labels
5. Click "Send Message"

### Testing Automation

1. Navigate to "WhatsApp"
2. Click "Test Inactive Member Check"
3. System will find inactive members and send retention messages
4. Check backend logs for confirmation

## 🌟 FITBOT Personality Examples

### High-Energy Greetings

```
🔥 Rahul! Time to crush it at Azhar Fitness Center! Your gains are waiting!

💪 Hey Priya! The iron doesn't lift itself. Let's GO!

⚡ Amit, your body is calling - answer at AFC Gym NOW!
```

### Retention Messages

```
The only bad workout is the one that didn't happen.

Your goals don't care if you're tired.

Don't stop when you're tired. Stop when you're DONE.
```

## 📸 Screenshots

### Login Page
Clean, professional login with FITBOT branding

### Dashboard
Real-time stats and FITBOT feature overview

### Members Management
Full CRUD with Excel import/export

### WhatsApp Panel
Send messages with interactive buttons

### Instagram Content
Preview generated HD stories

## 🔧 Configuration

### Environment Variables

```env
# Database
MONGO_URL=mongodb://localhost:27017
DB_NAME=azharfit_saas

# Auth
JWT_SECRET=your-secret-key
ADMIN_EMAIL=Admin@azhartrainer.com
ADMIN_PASSWORD=Admin

# OpenAI
OPENAI_API_KEY=your-openai-key
EMERGENT_LLM_KEY=your-emergent-key
OPENAI_MODEL=gpt-3.5-turbo

# WhatsApp Business API
WHATSAPP_PHONE_NUMBER_ID=your-phone-id
WHATSAPP_ACCESS_TOKEN=your-access-token

# System
CORS_ORIGINS=*
LOG_LEVEL=debug
```

## 🛡️ Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Protected API routes
- CORS configuration
- Secure token storage

## 📈 Performance

- MongoDB for fast data access
- Async/await throughout
- Background task scheduling
- Efficient image generation
- Optimized API responses

## 🐛 Troubleshooting

### Backend Not Starting

```bash
# Check logs
tail -f /var/log/supervisor/backend.err.log

# Restart backend
sudo supervisorctl restart backend
```

### Frontend Issues

```bash
# Check logs
tail -f /var/log/supervisor/frontend.err.log

# Restart frontend
sudo supervisorctl restart frontend
```

### Database Connection

```bash
# Check MongoDB status
sudo supervisorctl status mongodb

# Restart MongoDB
sudo supervisorctl restart mongodb
```

## 📝 Future Enhancements

- [ ] SMS notifications via Twilio
- [ ] Payment integration with Razorpay
- [ ] Member mobile app
- [ ] Attendance tracking with QR codes
- [ ] Workout plan management
- [ ] Progress photos and measurements
- [ ] Referral system
- [ ] Email campaigns

## 👨‍💻 Development

### Running Tests

```bash
# Backend tests
cd /app/backend
pytest

# Frontend tests (if added)
cd /app/frontend
yarn test
```

### Code Quality

```bash
# Python linting
cd /app/backend
ruff check .

# JavaScript linting
cd /app/frontend
yarn lint
```

## 📄 License

Proprietary - Azhar Fitness Center

## 🙏 Credits

- **Development**: Built with Emergent AI
- **Design**: Blue/Orange/Chrome branding for Azhar Fitness Center
- **AI Integration**: OpenAI GPT-3.5-turbo & GPT Image 1
- **WhatsApp**: WhatsApp Business API

---

## 🔥 FITBOT Motto

**"The only bad workout is the one that didn't happen!"**

💪 High-Energy • ⚡ Motivational • 🎯 Dynamic • 🏋️ No-Nonsense

---

**Made with 🔥 by FITBOT for Azhar Fitness Center**
