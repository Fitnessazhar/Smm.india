import { useState, useEffect } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Image as ImageIcon, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

function Instagram() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await axios.get('/instagram/posts');
      setPosts(response.data);
    } catch (error) {
      toast.error('Failed to load Instagram posts');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      await axios.post('/instagram/generate');
      toast.success('Instagram content generated successfully!');
      await fetchPosts();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to generate content');
    } finally {
      setGenerating(false);
    }
  };

  const themes = [
    { name: 'Heavy Lifting', emoji: '🏋️', color: 'from-red-500 to-orange-600' },
    { name: 'Healthy Meal Prep', emoji: '🥗', color: 'from-green-500 to-teal-600' },
    { name: 'Success Quotes', emoji: '💪', color: 'from-purple-500 to-pink-600' },
    { name: 'Call to Action', emoji: '🎯', color: 'from-blue-500 to-cyan-600' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white text-xl">Loading Instagram posts...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in" data-testid="instagram-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Instagram Content</h1>
          <p className="text-gray-400">Daily HD stories (9:16 format)</p>
        </div>
        <Button
          onClick={handleGenerate}
          disabled={generating}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          data-testid="generate-instagram-button"
        >
          <Sparkles className="mr-2 h-4 w-4" />
          {generating ? 'Generating...' : 'Generate New Content'}
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {themes.map((theme) => (
          <Card key={theme.name} className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white text-sm flex items-center">
                <span className="text-2xl mr-2">{theme.emoji}</span>
                {theme.name}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={`h-32 rounded-lg bg-gradient-to-br ${theme.color} flex items-center justify-center text-white font-bold`}>
                AZHAR FITNESS
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">Generated Content ({posts.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {posts.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <ImageIcon className="mx-auto h-12 w-12 mb-4 opacity-50" />
              <p>No Instagram content generated yet.</p>
              <p className="text-sm">Click "Generate New Content" to create your first post!</p>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {posts.map((post) => (
                <Card key={post.id} className="bg-gray-700 border-gray-600">
                  <CardHeader>
                    <CardTitle className="text-white text-sm">
                      {post.theme}
                    </CardTitle>
                    <p className="text-xs text-gray-400">
                      {format(new Date(post.created_at), 'MMM dd, yyyy HH:mm')}
                    </p>
                  </CardHeader>
                  <CardContent>
                    {post.image_base64 ? (
                      <img
                        src={`data:image/png;base64,${post.image_base64}`}
                        alt={post.theme}
                        className="w-full h-64 object-cover rounded-lg"
                      />
                    ) : (
                      <div className="w-full h-64 bg-gray-600 rounded-lg flex items-center justify-center text-gray-400">
                        <ImageIcon className="h-12 w-12" />
                      </div>
                    )}
                    <p className="text-xs text-gray-400 mt-2 line-clamp-3">{post.prompt}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-blue-600 to-orange-600 border-none text-white">
        <CardHeader>
          <CardTitle>Branding Guidelines</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p>🎨 <strong>Colors:</strong> Blue, Orange, Chrome</p>
          <p>📐 <strong>Format:</strong> 9:16 (Vertical HD Stories)</p>
          <p>🌟 <strong>Style:</strong> Hyper-realistic, Dramatic lighting</p>
          <p>🔄 <strong>Themes:</strong> Rotates through 4 themes daily</p>
          <p>👤 <strong>Consistency:</strong> Maintains Azhar Shaikh's brand identity</p>
        </CardContent>
      </Card>
    </div>
  );
}

export default Instagram;
