import { useState } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MessageSquare, Send, Zap } from 'lucide-react';
import { toast } from 'sonner';

function WhatsApp() {
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [buttons, setButtons] = useState(['Let\'s Go!', 'Not Today', 'Contact Admin']);
  const [includeButtons, setIncludeButtons] = useState(true);
  const [sending, setSending] = useState(false);
  const [testingInactive, setTestingInactive] = useState(false);

  const handleSend = async () => {
    if (!phone || !message) {
      toast.error('Please enter phone and message');
      return;
    }

    setSending(true);
    try {
      await axios.post('/whatsapp/send', {
        phone,
        message,
        buttons: includeButtons ? buttons : null,
      });
      toast.success('WhatsApp message sent successfully!');
      setMessage('');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleTestInactive = async () => {
    setTestingInactive(true);
    try {
      await axios.post('/whatsapp/test-inactive');
      toast.success('Inactive member check completed! Check console for details.');
    } catch (error) {
      toast.error('Failed to run inactive member check');
    } finally {
      setTestingInactive(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in" data-testid="whatsapp-page">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">WhatsApp Management</h1>
        <p className="text-gray-400">Send messages and manage automation</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <MessageSquare className="mr-2 h-5 w-5 text-green-500" />
              Send WhatsApp Message
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-gray-300">Phone Number (with country code)</Label>
              <Input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+911234567890"
                className="bg-gray-700 border-gray-600 text-white"
                data-testid="phone-input"
              />
            </div>

            <div>
              <Label className="text-gray-300">Message</Label>
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter your message..."
                rows={6}
                className="bg-gray-700 border-gray-600 text-white"
                data-testid="message-input"
              />
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="includeButtons"
                checked={includeButtons}
                onChange={(e) => setIncludeButtons(e.target.checked)}
                className="w-4 h-4"
              />
              <Label htmlFor="includeButtons" className="text-gray-300">
                Include Interactive Buttons
              </Label>
            </div>

            {includeButtons && (
              <div className="space-y-2">
                <Label className="text-gray-300">Button Options</Label>
                {buttons.map((btn, idx) => (
                  <Input
                    key={idx}
                    value={btn}
                    onChange={(e) => {
                      const newButtons = [...buttons];
                      newButtons[idx] = e.target.value;
                      setButtons(newButtons);
                    }}
                    className="bg-gray-700 border-gray-600 text-white"
                    maxLength={20}
                  />
                ))}
              </div>
            )}

            <Button
              onClick={handleSend}
              disabled={sending}
              className="w-full bg-green-600 hover:bg-green-700"
              data-testid="send-message-button"
            >
              <Send className="mr-2 h-4 w-4" />
              {sending ? 'Sending...' : 'Send Message'}
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="bg-gradient-to-br from-orange-600 to-blue-700 border-none text-white">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5" />
                FITBOT Features
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <p className="font-semibold">✅ Anti-Repetition Logic</p>
                <p className="text-sm opacity-90">10+ greeting variations, never repeats</p>
              </div>
              <div>
                <p className="font-semibold">✅ Retention Mode</p>
                <p className="text-sm opacity-90">Activates for members inactive >3 days</p>
              </div>
              <div>
                <p className="font-semibold">✅ Psychological Triggers</p>
                <p className="text-sm opacity-90">Motivational messages that inspire action</p>
              </div>
              <div>
                <p className="font-semibold">✅ Interactive Buttons</p>
                <p className="text-sm opacity-90">Every message includes action buttons</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Automation Controls</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-gray-300 mb-2">Test inactive member detection and send retention messages:</p>
                <Button
                  onClick={handleTestInactive}
                  disabled={testingInactive}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                  data-testid="test-inactive-button"
                >
                  {testingInactive ? 'Running...' : 'Test Inactive Member Check'}
                </Button>
              </div>

              <div className="pt-4 border-t border-gray-700">
                <p className="text-sm text-gray-400">
                  <strong>Automated Schedule:</strong><br />
                  • Inactive member check: Daily at 9:00 AM<br />
                  • Instagram generation: Daily at 10:00 AM
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Sample Greetings</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>🔥 Time to crush it at Azhar Fitness Center!</li>
                <li>💪 The iron doesn't lift itself. Let's GO!</li>
                <li>⚡ Your body is calling - answer at AFC Gym NOW!</li>
                <li>🎯 Missed you at the gym! Time to get back on track!</li>
                <li>🔱 Azhar Fitness is calling your name!</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default WhatsApp;
