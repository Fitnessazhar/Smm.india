import { useState, useEffect } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Pencil, Trash2, Download, Upload, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { format } from 'date-fns';

function Members() {
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedMember, setSelectedMember] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
  });

  useEffect(() => {
    fetchMembers();
  }, []);

  const fetchMembers = async () => {
    try {
      const response = await axios.get('/members');
      setMembers(response.data);
    } catch (error) {
      toast.error('Failed to load members');
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = async () => {
    try {
      await axios.post('/members', formData);
      toast.success('Member added successfully!');
      setShowAddDialog(false);
      setFormData({ name: '', phone: '', email: '' });
      fetchMembers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to add member');
    }
  };

  const handleEdit = async () => {
    try {
      await axios.put(`/members/${selectedMember.id}`, formData);
      toast.success('Member updated successfully!');
      setShowEditDialog(false);
      setSelectedMember(null);
      setFormData({ name: '', phone: '', email: '' });
      fetchMembers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to update member');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this member?')) return;
    
    try {
      await axios.delete(`/members/${id}`);
      toast.success('Member deleted successfully!');
      fetchMembers();
    } catch (error) {
      toast.error('Failed to delete member');
    }
  };

  const handleCheckin = async (id) => {
    try {
      await axios.post(`/members/${id}/checkin`);
      toast.success('Check-in recorded!');
      fetchMembers();
    } catch (error) {
      toast.error('Failed to record check-in');
    }
  };

  const openEditDialog = (member) => {
    setSelectedMember(member);
    setFormData({
      name: member.name,
      phone: member.phone,
      email: member.email || '',
    });
    setShowEditDialog(true);
  };

  const exportToExcel = () => {
    const exportData = members.map((m) => ({
      Name: m.name,
      Phone: m.phone,
      Email: m.email || '',
      'Last Check-in': m.last_checkin ? format(new Date(m.last_checkin), 'yyyy-MM-dd HH:mm') : 'Never',
      'Join Date': format(new Date(m.join_date), 'yyyy-MM-dd'),
      Status: m.membership_status,
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Members');
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(data, `azhar_fitness_members_${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
    toast.success('Members exported successfully!');
  };

  const importFromExcel = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws);

        let successCount = 0;
        let errorCount = 0;

        for (const row of data) {
          try {
            await axios.post('/members', {
              name: row.Name || row.name,
              phone: String(row.Phone || row.phone),
              email: row.Email || row.email || '',
            });
            successCount++;
          } catch (error) {
            errorCount++;
          }
        }

        toast.success(`Imported ${successCount} members successfully! ${errorCount} errors.`);
        fetchMembers();
      } catch (error) {
        toast.error('Failed to import members');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white text-xl">Loading members...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in" data-testid="members-page">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Members Management</h1>
          <p className="text-gray-400">Manage your gym members</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={exportToExcel}
            variant="outline"
            className="bg-green-600 hover:bg-green-700 text-white border-none"
            data-testid="export-button"
          >
            <Download className="mr-2 h-4 w-4" />
            Export Excel
          </Button>
          <label>
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={importFromExcel}
              className="hidden"
            />
            <Button
              as="span"
              variant="outline"
              className="bg-blue-600 hover:bg-blue-700 text-white border-none cursor-pointer"
              data-testid="import-button"
            >
              <Upload className="mr-2 h-4 w-4" />
              Import Excel
            </Button>
          </label>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="bg-orange-600 hover:bg-orange-700" data-testid="add-member-button">
                <Plus className="mr-2 h-4 w-4" />
                Add Member
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-800 text-white border-gray-700">
              <DialogHeader>
                <DialogTitle>Add New Member</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter name"
                    className="bg-gray-700 border-gray-600 text-white"
                    data-testid="member-name-input"
                  />
                </div>
                <div>
                  <Label>Phone (with country code)</Label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+911234567890"
                    className="bg-gray-700 border-gray-600 text-white"
                    data-testid="member-phone-input"
                  />
                </div>
                <div>
                  <Label>Email (Optional)</Label>
                  <Input
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="email@example.com"
                    className="bg-gray-700 border-gray-600 text-white"
                    data-testid="member-email-input"
                  />
                </div>
                <Button
                  onClick={handleAdd}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                  data-testid="save-member-button"
                >
                  Add Member
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white">All Members ({members.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-700">
                  <TableHead className="text-gray-300">Name</TableHead>
                  <TableHead className="text-gray-300">Phone</TableHead>
                  <TableHead className="text-gray-300">Email</TableHead>
                  <TableHead className="text-gray-300">Last Check-in</TableHead>
                  <TableHead className="text-gray-300">Status</TableHead>
                  <TableHead className="text-gray-300 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {members.map((member) => (
                  <TableRow key={member.id} className="border-gray-700" data-testid={`member-row-${member.id}`}>
                    <TableCell className="text-white font-medium">{member.name}</TableCell>
                    <TableCell className="text-gray-300">{member.phone}</TableCell>
                    <TableCell className="text-gray-300">{member.email || '-'}</TableCell>
                    <TableCell className="text-gray-300">
                      {member.last_checkin
                        ? format(new Date(member.last_checkin), 'MMM dd, yyyy HH:mm')
                        : 'Never'}
                    </TableCell>
                    <TableCell>
                      <span
                        className={`px-2 py-1 rounded text-xs font-semibold ${
                          member.membership_status === 'active'
                            ? 'bg-green-600 text-white'
                            : 'bg-red-600 text-white'
                        }`}
                      >
                        {member.membership_status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button
                        size="sm"
                        onClick={() => handleCheckin(member.id)}
                        className="bg-green-600 hover:bg-green-700"
                        data-testid={`checkin-button-${member.id}`}
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => openEditDialog(member)}
                        className="bg-blue-600 hover:bg-blue-700 text-white border-none"
                        data-testid={`edit-button-${member.id}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => handleDelete(member.id)}
                        data-testid={`delete-button-${member.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-800 text-white border-gray-700">
          <DialogHeader>
            <DialogTitle>Edit Member</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label>Phone</Label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <div>
              <Label>Email</Label>
              <Input
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
            <Button onClick={handleEdit} className="w-full bg-orange-600 hover:bg-orange-700">
              Update Member
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default Members;
