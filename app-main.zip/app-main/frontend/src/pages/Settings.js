import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings as SettingsIcon, Database, MessageSquare, Image, Key } from 'lucide-react';

function Settings() {
  return (
    <div className="space-y-6 animate-fade-in" data-testid="settings-page">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Settings</h1>
        <p className="text-gray-400">FITBOT configuration and system information</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Database className="mr-2 h-5 w-5 text-blue-500" />
              Database Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-gray-300">
            <p><strong>Host:</strong> manageserver.in</p>
            <p><strong>Database:</strong> azharfit_ness</p>
            <p><strong>Status:</strong> <span className="text-green-500">✓ Connected</span></p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <MessageSquare className="mr-2 h-5 w-5 text-green-500" />
              WhatsApp Integration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-gray-300">
            <p><strong>Provider:</strong> WhatsApp Business API</p>
            <p><strong>Phone ID:</strong> 1008484319012502</p>
            <p><strong>Status:</strong> <span className="text-green-500">✓ Configured</span></p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Key className="mr-2 h-5 w-5 text-purple-500" />
              OpenAI Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-gray-300">
            <p><strong>Model:</strong> gpt-3.5-turbo</p>
            <p><strong>Image Generation:</strong> gpt-image-1</p>
            <p><strong>Status:</strong> <span className="text-green-500">✓ Active</span></p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Image className="mr-2 h-5 w-5 text-pink-500" />
              Instagram Automation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm text-gray-300">
            <p><strong>Format:</strong> 9:16 HD Stories</p>
            <p><strong>Schedule:</strong> Daily at 10:00 AM</p>
            <p><strong>Status:</strong> <span className="text-green-500">✓ Scheduled</span></p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <SettingsIcon className="mr-2 h-5 w-5 text-orange-500" />
            FITBOT Automation Schedule
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-gray-300">
          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <div>
              <p className="font-semibold">Inactive Member Check</p>
              <p className="text-sm text-gray-400">Sends retention messages to members inactive >3 days</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-orange-400">Daily 9:00 AM</p>
              <p className="text-xs text-green-500">✓ Active</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <div>
              <p className="font-semibold">Instagram Content Generation</p>
              <p className="text-sm text-gray-400">Generates daily HD story with rotating themes</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-orange-400">Daily 10:00 AM</p>
              <p className="text-xs text-green-500">✓ Active</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-orange-600 to-blue-700 border-none text-white">
        <CardHeader>
          <CardTitle>FITBOT System Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <p><strong>Version:</strong> 1.0.0</p>
          <p><strong>Environment:</strong> Production</p>
          <p><strong>Admin Email:</strong> Admin@azhartrainer.com</p>
          <p className="pt-4 border-t border-white/20">
            <strong>Features:</strong>
          </p>
          <ul className="space-y-1 text-sm">
            <li>✓ 10+ Anti-Repetition Greetings</li>
            <li>✓ AI-Powered Conversations (GPT-3.5-turbo)</li>
            <li>✓ Automated WhatsApp Messaging</li>
            <li>✓ HD Instagram Story Generation</li>
            <li>✓ Member Management & Excel Import/Export</li>
            <li>✓ Interactive WhatsApp Buttons</li>
            <li>✓ Psychological Retention Triggers</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

export default Settings;
