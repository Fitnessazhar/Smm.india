import { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, UserCheck, UserX, Activity } from 'lucide-react';
import { toast } from 'sonner';

function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await axios.get('/dashboard/stats');
      setStats(response.data);
    } catch (error) {
      toast.error('Failed to load dashboard stats');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white text-xl">Loading dashboard...</div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Members',
      value: stats?.total_members || 0,
      icon: Users,
      color: 'from-blue-500 to-blue-700',
      testId: 'total-members-card'
    },
    {
      title: 'Active Members',
      value: stats?.active_members || 0,
      icon: UserCheck,
      color: 'from-green-500 to-green-700',
      testId: 'active-members-card'
    },
    {
      title: 'Inactive Members',
      value: stats?.inactive_members || 0,
      icon: UserX,
      color: 'from-orange-500 to-orange-700',
      testId: 'inactive-members-card'
    },
    {
      title: 'Check-ins Today',
      value: stats?.checkins_today || 0,
      icon: Activity,
      color: 'from-purple-500 to-purple-700',
      testId: 'checkins-today-card'
    },
  ];

  return (
    <div className="space-y-6 animate-fade-in" data-testid="dashboard-page">
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
        <p className="text-gray-400">Welcome to FITBOT Control Center</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.title} className="bg-gray-800 border-gray-700" data-testid={card.testId}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">
                  {card.title}
                </CardTitle>
                <div className={`p-2 rounded-lg bg-gradient-to-br ${card.color}`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">{card.value}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">FITBOT Features</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
              <span>✅ WhatsApp Auto-Reply (Anti-Repetition Logic)</span>
            </div>
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
              <span>✅ Inactive Member Detection (>3 days)</span>
            </div>
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
              <span>✅ Daily Instagram HD Story Generation</span>
            </div>
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
              <span>✅ AI-Powered Motivational Messages</span>
            </div>
            <div className="flex items-center text-gray-300">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
              <span>✅ Interactive WhatsApp Buttons</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-600 to-blue-700 border-none text-white">
          <CardHeader>
            <CardTitle>FITBOT Personality</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-lg font-semibold">🔥 High-Energy</p>
            <p className="text-lg font-semibold">💪 No-Nonsense</p>
            <p className="text-lg font-semibold">⚡ Motivational</p>
            <p className="text-lg font-semibold">🎯 Dynamic</p>
            <p className="text-sm mt-4 opacity-90">
              "The only bad workout is the one that didn't happen!"
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default Dashboard;
